// js
import './js/common'
import './js/todolist'

// scss
import './assets/scss/main.scss'

